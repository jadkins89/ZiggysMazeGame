# ZiggysMazeGame
A terminal maze game that has dynamic size constraints. Boards are randomly generated and tested to guarantee a path to the finish line.

Instructions:
1. Clone
2. Modify the __ROW__ / __COL__ definitions in the __Board.h__ file to your liking
3. Run make in terminal inside the directory
4. Have fun.
